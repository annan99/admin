<template>
    <div>
    <h1>欢迎各位小可爱</h1>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="less" scoped>

</style>